DROP TABLE dolgoz�;
CREATE TABLE dolgoz� AS  SELECT * FROM emp;

SET serveroutput ON

DECLARE
  CURSOR egydolgoz� IS
    SELECT * FROM dolgoz� WHERE mgr IS NOT NULL FOR UPDATE OF comm NOWAIT;
  darab number;
  sz�zal�k number;
  jutalom number;
  PROCEDURE beosztottaksz�ma(id IN NUMBER, db OUT NUMBER) IS
  BEGIN
    SELECT count(*) INTO db FROM dolgoz� WHERE mgr = id;
  END beosztottaksz�ma;
BEGIN
	FOR d IN egydolgoz� LOOP
    beosztottaksz�ma(d.empno, darab);
    if darab = 0 then sz�zal�k := 10;
    elsif darab > 2 then sz�zal�k := 8;
    else sz�zal�k := 4;
    end if;
    jutalom := NVL(d.comm, 0) + d.sal*sz�zal�k/100;
    update dolgoz� set comm = jutalom where current of egydolgoz�;
	END LOOP; 
END;
/
select * from dolgoz�;