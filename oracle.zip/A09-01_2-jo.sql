-- A09-01_1-j�.sql
--------------------------------------------------------------
--                                                          --
--  Kende M�ria, Nagy Istv�n: Oracle P�ldat�r (SQL-PL/SQL)  --
--                                                          --
--  Copyright (c) Panem K�nyvkiad�, 2005                    --
--                                                          --
--------------------------------------------------------------

DROP TABLE dolgoz�;

CREATE TABLE dolgoz�
AS  SELECT * FROM emp;

SET serveroutput ON

DECLARE
  CURSOR egydolgoz� IS
    SELECT empno, ename, sal
      FROM dolgoz�
      WHERE UPPER(job) = 'CLERK'
      FOR UPDATE NOWAIT;

  azonos�t�  dolgoz�.empno%TYPE;
  n�v        dolgoz�.ename%TYPE;
  fizet�s    dolgoz�.sal%TYPE;

BEGIN 
  OPEN egydolgoz�;
  LOOP
    FETCH egydolgoz�
      INTO azonos�t�, n�v, fizet�s;
    EXIT  WHEN egydolgoz�%NOTFOUND;
    fizet�s := fizet�s *1.2;

    UPDATE dolgoz�
      SET sal = fizet�s
      WHERE CURRENT OF egydolgoz�;

    DBMS_OUTPUT.PUT_LINE( n�v||'   '||fizet�s);
  END LOOP;
  CLOSE egydolgoz�;
END;
/

SET numwidth 6
SELECT * FROM dolgoz�;
SET numwidth 10