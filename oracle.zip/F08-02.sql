-- K�rjen be k�t eg�sz sz�mot �s d�ntse el, hogy az �sszeg�k p�ros-e vagy p�ratlan.

-- 1. megold�s: SQL*Plus felhaszn�l�i v�ltoz�k haszn�lat�val
SET serveroutput ON
DECLARE 
  C NUMBER;
BEGIN
  C := &A + &B;
  IF MOD(C, 2) = 1 THEN
    DBMS_OUTPUT.PUT_LINE( C || ' p�ratlan');
  ELSE
    DBMS_OUTPUT.PUT_LINE( C || ' p�ros');
  END IF;
END;


-- 2. megoold�s: SQL*Plus k�rnyezeti v�ltoz�k haszn�lat�val
SET serveroutput ON
VARIABLE C NUMBER
BEGIN
  :C := &A + &B;
  IF MOD(:C, 2) = 1 THEN
    DBMS_OUTPUT.PUT_LINE( :C || ' p�ratlan');
  ELSE
    DBMS_OUTPUT.PUT_LINE( :C || ' p�ros');
  END IF;
END;
