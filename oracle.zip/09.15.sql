DROP TABLE rally;
CREATE TABLE rally ( 
  n�v          VARCHAR2(25), 
  nemzetis�g   VARCHAR2(20),
  feladatk�r   VARCHAR2(9),
  min�sit�s    NUMBER(3),
  partner      VARCHAR2(25)
);

INSERT INTO rally VALUES ('Gyula'    ,'HUN'   ,'PILOT'    ,50,   '---');
INSERT INTO rally VALUES ('White'    ,'GBR'   ,'PILOT'    ,72,   '---');
INSERT INTO rally VALUES ('van Glut' ,'NED'   ,'PILOT'    ,60,   '---');
INSERT INTO rally VALUES ('S�ndor'   ,'HUN'   ,'PILOT'    ,67,   '---');
INSERT INTO rally VALUES ('Piere'    ,'FRA'   ,'PILOT'    ,57,   '---');
INSERT INTO rally VALUES ('Mikl�s'   ,'HUN'   ,'PILOT'    ,80,   '---');
INSERT INTO rally VALUES ('Wraclaw'  ,'POL'   ,'NAVIGATOR',55,   '---');
INSERT INTO rally VALUES ('Nitzky'   ,'POL'   ,'NAVIGATOR',76,   '---');
INSERT INTO rally VALUES ('ONeil'    ,'GBR'   ,'NAVIGATOR',67,   '---');
INSERT INTO rally VALUES ('Kert�sz'  ,'HUN'   ,'NAVIGATOR',55,   '---');

-- 2. l�p�s (Partnerkeres�s)
SET serveroutput ON

DECLARE
  CURSOR pil�t�k IS 
    SELECT * FROM rally WHERE partner = '---' AND feladatk�r = 'PILOT';

  CURSOR navig�torok IS 
    SELECT * FROM rally WHERE partner = '---' AND feladatk�r = 'NAVIGATOR';

BEGIN
  FOR p IN pil�t�k LOOP
    FOR n IN navig�torok LOOP
      IF (p.nemzetis�g = n.nemzetis�g) AND (ABS(p.min�sit�s - n.min�sit�s) < 20) THEN
        UPDATE rally SET partner = n.n�v WHERE n�v = p.n�v;
        UPDATE rally SET partner = p.n�v WHERE n�v = n.n�v;
        EXIT;
      END IF;
    END LOOP; -- loop n
  END LOOP;  -- loop p
END;
/
SELECT n�v, partner FROM rally WHERE partner != '---';
