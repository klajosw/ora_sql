SELECT owner, COUNT(*) 
FROM all_tables
GROUP BY owner 
HAVING count(*) > &1;