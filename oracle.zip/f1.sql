SELECT table_name, num_rows
FROM all_tables
WHERE num_rows > &1;