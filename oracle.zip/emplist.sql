CREATE OR REPLACE AND COMPILE JAVA SOURCE NAMED "EmpList" AS
import java.sql.*;
import oracle.jdbc.driver.OracleDriver;

public class EmpList {

  public static void list() {

    Connection connection = null; // Database connection object
    try {
      // Get a Default Database Connection using Server Side JDBC Driver. 
      // Note : This class will be loaded on the Database Server and hence use a  Server Side JDBC Driver to get default Connection to Database
      connection = new OracleDriver().defaultConnection();

      // Query to find out Standard Room Rates for a given Hotel and Room Type
      Statement stmt = connection.createStatement();
      ResultSet rs = stmt.executeQuery("SELECT * FROM emp");
      
      // Loop through the Resultset and fetch the results
      while (rs.next()) {
        System.out.println( rs.getString(2) );
      }

      rs.close();
      stmt.close();
    } 
    catch (SQLException ex) { // Trap SQL Errors
      ex.printStackTrace();
    } 
    finally {
      try{
        if (connection != null || !connection.isClosed()) connection.close();
      } 
      catch(SQLException ex){ ex.printStackTrace(); }
    }
  }
};
/
