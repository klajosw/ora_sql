drop table fibon;
create table fibon (
  n number,
  fib number
);

DECLARE
  num NUMBER;
  a NUMBER := 1;
  b NUMBER := 1;
  c NUMBER;
BEGIN
  INSERT INTO fibon VALUES (1, 1);
  INSERT INTO fibon VALUES (2, 1);
  FOR num IN 3..20 LOOP
    c := a + b;
    INSERT INTO fibon VALUES (num, c);
    a := b;
    b := c;
  END LOOP;
END;
/