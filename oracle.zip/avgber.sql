ACCEPT nagyobb PROMPT 'Adjon meg egy �sszeget: '
DECLARE
  FUNCTION avgber (bernelnagyobb IN NUMBER) RETURN NUMBER
  IS
    tmp_ber DEMO.munkatars.ber%TYPE;
  BEGIN
    SELECT AVG(ber) 
    into tmp_ber 
    FROM DEMO.MUNKATARS 
    where ber > bernelnagyobb;
    RETURN tmp_ber;
  END avgber;
BEGIN
  DBMS_OUTPUT.PUT_LINE('Eredm: ' || avgber(&nagyobb) );
END;
/

