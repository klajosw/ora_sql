-- Hozzunk l�tre egy gy�jt�t�bl�t, tegy�k bele az elemeket a demo.vev� t�bl�b�l, adjuk hozz� 
-- m�g egy vev�t, t�r�lj�k ki a p�ratlan index�eket, �rjuk ki a t�bla tartalm�t
DECLARE
  TYPE tipus IS TABLE OF DEMO.vevo%ROWTYPE INDEX BY BINARY_INTEGER;
  gyt tipus;
BEGIN
  for i in 21..28 loop
    SELECT * INTO gyt(i)
    FROM DEMO.vevo WHERE partner_id = i;
  END LOOP;
  
  gyt(2).partner_id := 2;
  gyt(22).megnevezes := 'megnev';
  
  for i in gyt.FIRST..gyt.LAST loop
    if MOD(i, 2) = 1 then gyt.delete(i); end if;
  end loop;

  for i in gyt.FIRST..gyt.LAST LOOP
    if gyt.exists(i) then
      DBMS_OUTPUT.PUT_LINE( i || ' ' || gyt(i).partner_id || gyt(i).megnevezes);
    end if;
  END LOOP;
END;
/